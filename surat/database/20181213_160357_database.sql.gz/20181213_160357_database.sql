-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: December 13, 2018 at 16:03 PM ( ASIA/JAKARTA )
-- PHP Version: 7.0.28
--
-- ---------------------------------------------------------



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `instansi`
--
-- ---------------------------------------------------------

CREATE TABLE `instansi` (
  `id_instansi` int(11) NOT NULL,
  `nama_instansi` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_instansi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instansi`
--

INSERT INTO `instansi` (`id_instansi`, `nama_instansi`, `alamat`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'SEKSI PENAGIHAN', 'LANTAI 3', 1, '2018-12-13 14:08:05', '', ''),
(2, 'SEKSI PEMERIKSAAN', 'LANTAI 3', 1, '2018-12-13 14:08:15', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `surat_keluar`
--
-- ---------------------------------------------------------

CREATE TABLE `surat_keluar` (
  `id_surat_keluar` bigint(20) NOT NULL,
  `nomor_agenda` bigint(20) NOT NULL,
  `tanggal_register` date NOT NULL,
  `tujuan_surat` int(11) NOT NULL,
  `nomor_surat` varchar(50) NOT NULL,
  `tanggal_surat` date NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `arsip` varchar(255) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_surat_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



-- ---------------------------------------------------------
--
-- Table structure for table : `surat_masuk`
--
-- ---------------------------------------------------------

CREATE TABLE `surat_masuk` (
  `id_surat_masuk` bigint(20) NOT NULL,
  `nomor_agenda` bigint(20) NOT NULL,
  `tanggal_diterima` date NOT NULL,
  `asal_surat` int(11) NOT NULL,
  `nomor_surat` varchar(50) NOT NULL,
  `tanggal_surat` date NOT NULL,
  `sifat_surat` enum('Rahasia','Penting','Biasa') NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `arsip` varchar(255) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_surat_masuk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `surat_masuk`
--

INSERT INTO `surat_masuk` (`id_surat_masuk`, `nomor_agenda`, `tanggal_diterima`, `asal_surat`, `nomor_surat`, `tanggal_surat`, `sifat_surat`, `perihal`, `keterangan`, `arsip`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 1, '2018-12-13', 1, 321, '2018-12-13', 'Penting', 'dsfd', 'dsfdsf', '', 1, '2018-12-13 14:17:04', '', ''),
(2, 2, '2018-12-13', 2, 3211, '2018-12-12', 'Rahasia', 'tes tes', 'tes tess', '', 1, '2018-12-13 14:50:24', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_audit_trail`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_audit_trail` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(30) NOT NULL,
  `action` enum('Insert','Update','Delete') NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_audit_trail`
--

INSERT INTO `sys_audit_trail` (`ID`, `datetime`, `username`, `action`, `description`) VALUES
(1, '2018-05-18 08:08:20', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(2, '2018-12-13 10:14:03', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(3, '2018-12-13 10:14:18', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(4, '2018-12-13 10:20:27', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>b4c1d29ca4cbaac745f196a84d350b3f<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(5, '2018-12-13 10:30:04', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b><b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(6, '2018-12-13 10:32:37', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b><b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>tomat<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(7, '2018-12-13 11:05:33', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(8, '2018-12-13 11:11:27', 1, 'Update', '<b>Update</b> data instansi pada tabel <b>sys_config</b>.<br><b>Data Lama = [Nama Instansi : </b>SMK NUSANTARA<b>][Alamat : </b>Jalan Teuku Umar No 100, Kedaton, Bandar Lampung, Lampung<b>][Telepon : </b>081377783334<b>][Fax : </b>081377783334<b>][Email : </b>smknusantara@gmail.com<b>][Website : </b>www.smknusantara.sch.id<b>][Logo : </b>logo.png<b>],<br> Data Baru = [Nama Instansi : </b>KPP PRATAMA MALANG UTARA<b>][Alamat : </b>Jalan Jaksa Agung Suprapto 29<b>][Telepon : </b>081377783334<b>][Fax : </b>081377783334<b>][Email : </b>malangutara@gmail.com<b>][Website : </b>http://malangutara.com<b>][Logo : </b>logo.png<b>]</b>'),
(9, '2018-12-13 11:12:18', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>herry<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(10, '2018-12-13 11:12:42', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>herry<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>herry<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(11, '2018-12-13 11:13:25', 1, 'Insert', '<b>Insert</b> data backup database pada tabel <b>sys_database</b>.<br><b>[ID : </b>1<b>][Nama File : </b>20181213_111325_database.sql.gz<b>][Ukuran File : </b>2 KB<b>]</b>'),
(12, '2018-12-13 14:08:05', 1, 'Insert', '<b>Insert</b> data instansi pada tabel <b>instansi</b>.<br><b>[ID Instansi : </b>1<b>][Nama Instansi : </b>SEKSI PENAGIHAN<b>][Alamat : </b>LANTAI 3<b>]</b>'),
(13, '2018-12-13 14:08:15', 1, 'Insert', '<b>Insert</b> data instansi pada tabel <b>instansi</b>.<br><b>[ID Instansi : </b>2<b>][Nama Instansi : </b>SEKSI PEMERIKSAAN<b>][Alamat : </b>LANTAI 3<b>]</b>'),
(14, '2018-12-13 14:17:04', 1, 'Insert', '<b>Insert</b> data surat masuk pada tabel <b>surat masuk</b>.<br><b>[ID Surat Masuk : </b>1<b>][Nomor Agenda : </b>1<b>][Tanggal Diterima : </b>2018-12-13<b>][ID Instansi : </b>1<b>][Nomor Surat : </b>321<b>][Tanggal Surat : </b>2018-12-13<b>][Sifat Surat : </b>Penting<b>][Perihal : </b>dsfd<b>][Keterangan : </b>dsfdsf<b>][Arsip : </b><b>]</b>'),
(15, '2018-12-13 14:42:27', 1, 'Update', '<b>Update</b> data user pada tabel <b>sys_users</b>.<br><b>Data Lama = [ID User : </b>1<b>][Nama User : </b>herry<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>],<br> Data Baru = [ID User : </b>1<b>][Nama User : </b>herry<b>][Username : </b>admin<b>][Password : </b>0937afa17f4dc08f3c0e5dc908158370ce64df86<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(16, '2018-12-13 14:44:07', 1, 'Update', '<b>Update</b> data instansi pada tabel <b>sys_config</b>.<br><b>Data Lama = [Nama Instansi : </b>KPP PRATAMA MALANG UTARA<b>][Alamat : </b>Jalan Jaksa Agung Suprapto 29<b>][Telepon : </b>081377783334<b>][Fax : </b>081377783334<b>][Email : </b>malangutara@gmail.com<b>][Website : </b>http://malangutara.com<b>][Logo : </b>logo.png<b>],<br> Data Baru = [Nama Instansi : </b>KPP PRATAMA MALANG UTARA<b>][Alamat : </b>Jalan Jaksa Agung Suprapto 29<b>][Telepon : </b>081377783334<b>][Fax : </b>081377783334<b>][Email : </b>malangutara@gmail.com<b>][Website : </b>http://malangutara.com<b>][Logo : </b>djp.jpg<b>]</b>'),
(17, '2018-12-13 14:50:24', 1, 'Insert', '<b>Insert</b> data surat masuk pada tabel <b>surat masuk</b>.<br><b>[ID Surat Masuk : </b>2<b>][Nomor Agenda : </b>2<b>][Tanggal Diterima : </b>2018-12-13<b>][ID Instansi : </b>2<b>][Nomor Surat : </b>3211<b>][Tanggal Surat : </b>2018-12-12<b>][Sifat Surat : </b>Rahasia<b>][Perihal : </b>tes tes<b>][Keterangan : </b>tes tess<b>][Arsip : </b><b>]</b>');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_config`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_config` (
  `configID` tinyint(1) NOT NULL,
  `nama_instansi` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `fax` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `logo` varchar(50) NOT NULL,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`configID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_config`
--

INSERT INTO `sys_config` (`configID`, `nama_instansi`, `alamat`, `telepon`, `fax`, `email`, `website`, `logo`, `updated_user`, `updated_date`) VALUES
(1, 'KPP PRATAMA MALANG UTARA', 'Jalan Jaksa Agung Suprapto 29', 081377783334, 081377783334, 'malangutara@gmail.com', 'http://malangutara.com', 'djp.jpg', 1, '2018-12-13 14:44:07');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_database`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_database` (
  `dbID` int(11) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_size` varchar(10) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dbID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_database`
--

INSERT INTO `sys_database` (`dbID`, `file_name`, `file_size`, `created_user`, `created_date`) VALUES
(1, '20181213_111325_database.sql.gz', '2 KB', 1, '2018-12-13 11:13:25');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_users`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_users` (
  `userID` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `user_account_name` varchar(30) NOT NULL,
  `user_account_password` varchar(45) NOT NULL,
  `user_permissions` enum('Administrator','Operator') NOT NULL,
  `block_users` enum('Ya','Tidak') NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `sys_users`
--

INSERT INTO `sys_users` (`userID`, `fullname`, `user_account_name`, `user_account_password`, `user_permissions`, `block_users`, `last_login`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'herry', 'admin', '0937afa17f4dc08f3c0e5dc908158370ce64df86', 'Administrator', 'Tidak', '2018-12-13 14:42:27', 1, '2018-04-01 01:01:01', 1, '2018-12-13 14:42:27');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;